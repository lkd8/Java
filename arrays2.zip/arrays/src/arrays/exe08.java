package arrays;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class exe08 {

    public static void main(String[] args) {
        Random random = new Random();
        int[] vetor = new int[10];
        Set<Integer> num = new HashSet<>();

        int index = 0;
        while (index < vetor.length) {
            int aleatorio = random.nextInt(100);


            if (!num.contains(aleatorio)) {
                vetor[index] = aleatorio;
                num.add(aleatorio);
                index++;
            }
        }


        System.out.println("resultado:");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
    }
}