//Escreva um programa em Java que preencha um vetor de 10 posições com valores 
//fornecidos pelo usuário. Imprima no vídeo a quantidade de números pares e ímpares 
//digitados.

package arrays;

import java.util.Scanner;

public class exe02 {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int[] vetor = new int[3];
		int par = 0;
		int impar = 0;
		
		for (int i = 0; i < vetor.length; i++) {
			System.out.println("numero " + (i + 1) + ":");
			vetor[i] = in.nextInt();

		
		if (vetor[i] % 2 == 0) {
			par++;
		} else {
			impar++;
		}
		}
		
		System.out.println("pares:" + par);
		System.out.println("impar:" + impar);
		
		in.close();

	}

}
