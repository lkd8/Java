package arrays;

import java.util.Scanner;

public class exe06 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        
        System.out.print("quantidade de elementos:");
        int n = in.nextInt();
        
        
        int[] vetor = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("elemento " + (i + 1) + ": ");
            vetor[i] = in.nextInt();
        }


        boolean especial = true;
        for (int i = 0; i < vetor.length - 1; i++) {
            if ((vetor[i] % 2 == 0 && vetor[i + 1] % 2 == 0) || (vetor[i] % 2 != 0 && vetor[i + 1] % 2 != 0)) {
                especial = false;
                break;
            }
        }


        if (especial) {
            System.out.println("O array é especial.");
        } else {
            System.out.println("O array não é especial.");
        }

        in.close();
    }
}