package arrays;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class exe08 {

    public static void main(String[] args) {
        Random random = new Random();
        int[] vetor = new int[10];
        Set<Integer> numerosGerados = new HashSet<>();

        int index = 0;
        while (index < vetor.length) {
            // Gera um número aleatório entre 0 e 99
            int numeroAleatorio = random.nextInt(100);

            // Verifica se o número já foi gerado
            if (!numerosGerados.contains(numeroAleatorio)) {
                vetor[index] = numeroAleatorio;
                numerosGerados.add(numeroAleatorio);
                index++;
            }
        }

        // Imprime o vetor de números aleatórios não duplicados
        System.out.println("Vetor preenchido com números aleatórios não duplicados:");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
    }
}