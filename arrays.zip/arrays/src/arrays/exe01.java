//Escreva um programa em Java que preencha um vetor de 10 posições com valores fornecidos 
//pelo usuário. Imprima no vídeo o maior e o menor valor armazenado.
//Observação: maior valor inteiro é Integer.MAX_VALUE e 
//o menor valor inteiro é Integer.MIN_VALUE.

package arrays;

import java.util.Scanner;

public class exe01 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int[] vetor = new int[3];
		int menor = Integer.MAX_VALUE;
		int maior = Integer.MIN_VALUE;

		
		for (int i = 0; i < vetor.length; i++) {
			System.out.println("posicao " + (i + 1) + ": ");
			vetor[i] = in.nextInt();
			
			if (vetor[i] < menor) {
				menor = vetor[i];
			}
			
			if (vetor[i] > maior) {
				maior = vetor[i];
				
			}
		
		}
		
		System.out.println("maior:" + maior);
		System.out.println("menor:" + menor);
		
		
		in.close();
		

	}

}
