package arrays;

import java.util.Scanner;

public class exe04 {
	

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double[] vetor = new double[3];
        String[] meses = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
            "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        double soma = 0;

        
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("temperatura " + meses[i] + ": ");
            vetor[i] = in.nextDouble();
            soma += vetor[i];
        }

        
        double media = soma / vetor.length;
        System.out.printf("media anual: %.2f°C%n", media);



        System.out.println("meses acima da media:");
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] > media) {
                System.out.printf("%d - %s: %.2f°C%n", (i + 1), meses[i], vetor[i]);
            }
        }

        in.close();
    }
}