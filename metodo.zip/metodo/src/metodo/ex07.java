package metodo;

import java.util.Random;

public class ex07 {

	public class DesvioPadraoVetor {

	    // Método para preencher o vetor com valores aleatórios
	    public static void preencherVetor(int[] vetor) {
	        Random random = new Random();
	        for (int i = 0; i < vetor.length; i++) {
	            vetor[i] = random.nextInt(101); // Preenche com valores aleatórios de 0 a 100
	        }
	    }

	    // Método para imprimir o vetor
	    public static void imprimirVetor(int[] vetor) {
	        System.out.println("Vetor:");
	        for (int valor : vetor) {
	            System.out.print(valor + " ");
	        }
	        System.out.println();
	    }

	    // Método para calcular a média do vetor
	    public static double calcularMedia(int[] vetor) {
	        int soma = 0;
	        for (int valor : vetor) {
	            soma += valor;
	        }
	        return (double) soma / vetor.length;
	    }

	    // Método para calcular o desvio padrão do vetor
	    public static double calcularDesvioPadrao(int[] vetor) {
	        double media = calcularMedia(vetor);
	        double somaDiferencasQuadrado = 0;

	        for (int valor : vetor) {
	            somaDiferencasQuadrado += Math.pow(valor - media, 2);
	        }

	        return Math.sqrt(somaDiferencasQuadrado / (vetor.length - 1));
	    }

	    // Método principal
	    public static void main(String[] args) {
	        int[] vetor = new int[10];

	        // Preenchendo o vetor com valores aleatórios
	        preencherVetor(vetor);

	        // Imprimindo o vetor
	        imprimirVetor(vetor);

	        // Calculando e imprimindo a média
	        double media = calcularMedia(vetor);
	        System.out.println("Média: " + media);

	        // Calculando e imprimindo o desvio padrão
	        double desvioPadrao = calcularDesvioPadrao(vetor);
	        System.out.println("Desvio Padrão: " + desvioPadrao);
	    }
	}
}