package arrays;

import java.util.Scanner;

public class exe05 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int[] vetor = new int[3];
		
		for (int i = 0; i < vetor.length; i++) {
			System.out.println("elemento " + (i + 1) + ":");
			vetor[i] = in.nextInt();
			
		}
		
		System.out.println("originais: ");
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i] + " ");
		}
		System.out.println();
		
		
		for (int i = 0; i < vetor.length / 2; i++) {
			int aux = vetor[i];
			vetor[i] = vetor[vetor.length - 1 - i ];
			vetor[vetor.length - 1 - i] = aux;
			
		}
		
		System.out.println("invertido: ");
		for (int i = 0; i < vetor.length; i++) {
			System.out.println(vetor[i] + " ");
		}
		System.out.println();

		in.close();
	}

}
