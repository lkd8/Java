package arrays;

import java.util.Arrays;
import java.util.Random;

public class exe010 {

    public static void main(String[] args) {
        Random random = new Random();
        int[] vetor = new int[10];


        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = random.nextInt(100);
        }


        System.out.println("ordem original: ");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
        System.out.println();


        Arrays.sort(vetor);


        System.out.println("ordem crescente: ");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
        System.out.println();
    }
}