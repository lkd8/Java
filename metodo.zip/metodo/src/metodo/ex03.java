package metodo;

import java.util.Scanner;

public class ex03 {

	public class Exercicio03 {
		public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			int x, y, z;
			
			System.out.print("primeiro valor --> ");
			x = sc.nextInt();
			System.out.print("segundo valor --> ");
			y = sc.nextInt();
			System.out.print("terceiro valor --> ");
			z = sc.nextInt();
			
			System.out.println("total = " + maiorValor(x, y, z));

		}
		
		public static int maiorValor(int x, int y, int z) {
			if(x > y && x > z) {
				return x;
			}
			else if(y > z) {
				return y;
			}
			return z;
		}
		
		
	}
		
	}
