package metodo;

import java.util.Random;

public class ex05 {



	public class VetorInversao {

	    // Método para preencher o vetor com valores aleatórios
	    public static void preencherVetor(int[] vetor) {
	        Random random = new Random();
	        for (int i = 0; i < vetor.length; i++) {
	            vetor[i] = random.nextInt(100); // Preenche com valores aleatórios de 0 a 99
	        }
	    }

	    // Método para imprimir o vetor
	    public static void imprimirVetor(int[] vetor) {
	        for (int valor : vetor) {
	            System.out.print(valor + " ");
	        }
	        System.out.println();
	    }

	    // Método para inverter o vetor
	    public static void inverterVetor(int[] vetor) {
	        int n = vetor.length;
	        for (int i = 0; i < n / 2; i++) {
	            int temp = vetor[i];
	            vetor[i] = vetor[n - 1 - i];
	            vetor[n - 1 - i] = temp;
	        }
	    }

	    // Método principal
	    public static void main(String[] args) {
	        int[] vetor = new int[10];
	        
	        // Preenchendo o vetor com valores aleatórios
	        preencherVetor(vetor);

	        // Imprimindo o vetor original
	        System.out.println("Vetor original:");
	        imprimirVetor(vetor);

	        // Invertendo o vetor
	        inverterVetor(vetor);

	        // Imprimindo o vetor invertido
	        System.out.println("Vetor invertido:");
	        imprimirVetor(vetor);
	    }
	}
	
}