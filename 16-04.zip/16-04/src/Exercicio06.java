
import java.util.Scanner;

public class Exercicio06 {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		String cargo;
		double tempo, aumento, salario;
		
		System.out.println("Cargo ");
		cargo = in.next();
		
		System.out.println("Tempo de Serviço ");
		tempo = in.nextDouble();
		
		System.out.println("Salário Atual ");
		salario = in.nextDouble();
		
		if(cargo.equalsIgnoreCase("gerente"))  {
			if(tempo >= 5) {
				aumento = salario * 1.1;
			}
			else if(tempo >= 3) {
				aumento = salario * 1.09;
			}
			else {
				aumento = salario * 1.08;
			}
		}
		else if(cargo.equalsIgnoreCase("engenheiro")) {
			if(tempo >= 5) {
				aumento = salario * 1.11;
			}
			else if(tempo >= 3) {
				aumento = salario * 1.1;
			}
			else {
				aumento = salario * 1.09;
			}
		}
		else if(cargo.equalsIgnoreCase("tecnico")) {
			if(tempo >= 5) {
				aumento = salario * 1.2;
			}
			else if(tempo >= 3) {
				aumento = salario * 1.11;
			}
			else {
				aumento = salario * 1.1;
			}
		}
		else {
			aumento = salario * 1.05;
		}
		
		System.out.println("Salario novo " + aumento);
		
		in.close();
		
		}
		

		
	}

