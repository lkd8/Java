package arrays;

import java.util.Scanner;

public class exe06 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Lê a quantidade de elementos do array
        System.out.print("Digite a quantidade de elementos no array: ");
        int n = scanner.nextInt();
        
        // Cria o array e armazena os elementos fornecidos pelo usuário
        int[] array = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Digite o elemento " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

        // Verifica se o array é especial
        boolean isEspecial = true;
        for (int i = 0; i < array.length - 1; i++) {
            if ((array[i] % 2 == 0 && array[i + 1] % 2 == 0) || (array[i] % 2 != 0 && array[i + 1] % 2 != 0)) {
                isEspecial = false;
                break;
            }
        }

        // Imprime o resultado
        if (isEspecial) {
            System.out.println("O array é especial.");
        } else {
            System.out.println("O array não é especial.");
        }

        scanner.close();
    }
}