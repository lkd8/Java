package seila;

import javax.swing.JOptionPane;

public class eg {

	public static void main(String[] args) {
		String[] dados = new String[3];
		double valor = 0;
		int opcao;
		
		
		opcao = Integer.parseInt(JOptionPane.showInputDialog("Digite a opção desejada\n 1. Abrir uma conta\n 2. Sacar\n 3.Depositar\n 4.Consultar Saldo\n 5. Fechar conta\n 6. Finalizar"));
		

	}

}
