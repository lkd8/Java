package metodo;

import java.util.Scanner;

public class ex01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int valor;
		
		System.out.print("Digite um valor inteiro e positivo: ");
		valor = sc.nextInt();
		if(valor <= 0) {
			System.out.println("valor inválido");
		}
		else {
			imprimir(valor);
		}
	}
	
	public static void imprimir(int valor) {
		for(int i = -valor; i <= valor; i++) {
			if(i != 0 && valor % i == 0) {
				System.out.print(i + "\t");
			}
		}
	}

}
