package metodo;

import java.util.Random;

public class ex06 {

	public class MatrizQuadrada {

	    // Método para preencher a matriz com valores aleatórios
	    public static void preencherMatriz(int[][] matriz) {
	        Random random = new Random();
	        for (int i = 0; i < matriz.length; i++) {
	            for (int j = 0; j < matriz[i].length; j++) {
	                matriz[i][j] = random.nextInt(100); // Preenche com valores aleatórios de 0 a 99
	            }
	        }
	    }

	    // Método para imprimir a matriz em formato tabular
	    public static void imprimirMatriz(int[][] matriz) {
	        for (int[] linha : matriz) {
	            for (int valor : linha) {
	                System.out.print(valor + "\t");
	            }
	            System.out.println();
	        }
	    }

	    // Método que retorna o maior valor de cada linha da matriz
	    public static int[] maiorValorPorLinha(int[][] matriz) {
	        int[] maioresValores = new int[matriz.length];
	        
	        for (int i = 0; i < matriz.length; i++) {
	            int maior = matriz[i][0];
	            for (int j = 1; j < matriz[i].length; j++) {
	                if (matriz[i][j] > maior) {
	                    maior = matriz[i][j];
	                }
	            }
	            maioresValores[i] = maior;
	        }
	        
	        return maioresValores;
	    }

	    // Método para imprimir o maior valor de cada linha da matriz
	    public static void imprimirMaioresValores(int[] maioresValores) {
	        System.out.println("Maiores valores de cada linha:");
	        for (int i = 0; i < maioresValores.length; i++) {
	            System.out.println("Linha " + (i + 1) + ": " + maioresValores[i]);
	        }
	    }

	    // Método principal
	    public static void main(String[] args) {
	        int tamanho = 4; // Definindo uma matriz quadrada de 4x4
	        int[][] matriz = new int[tamanho][tamanho];
	        
	        // Preenchendo a matriz com valores aleatórios
	        preencherMatriz(matriz);

	        // Imprimindo a matriz em formato tabular
	        System.out.println("Matriz preenchida:");
	        imprimirMatriz(matriz);

	        // Obtendo o maior valor de cada linha
	        int[] maioresValores = maiorValorPorLinha(matriz);

	        // Imprimindo os maiores valores de cada linha
	        imprimirMaioresValores(maioresValores);
	    }
	}
}
	