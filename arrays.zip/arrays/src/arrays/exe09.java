package arrays;

import java.util.Scanner;

public class exe09 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita o número de funcionários
        System.out.print("Digite o número de funcionários: ");
        int numFuncionarios = scanner.nextInt();
        scanner.nextLine();  // Consumir a nova linha após nextInt()

        String[] nomes = new String[numFuncionarios];
        double[] salarios = new double[numFuncionarios];

        // Lê o nome e o salário de cada funcionário
        for (int i = 0; i < numFuncionarios; i++) {
            System.out.print("Digite o nome do funcionário " + (i + 1) + ": ");
            nomes[i] = scanner.nextLine();

            System.out.print("Digite o salário de " + nomes[i] + ": ");
            salarios[i] = scanner.nextDouble();
            scanner.nextLine();  // Consumir a nova linha após nextDouble()
        }

        // Calcula o total e a média salarial
        double totalSalarios = 0;
        for (double salario : salarios) {
            totalSalarios += salario;
        }
        double mediaSalarial = totalSalarios / numFuncionarios;

        // Imprime o total gasto com a folha de pagamento e a média salarial
        System.out.printf("Total gasto com a folha de pagamento: R$ %.2f%n", totalSalarios);
        System.out.printf("Média salarial paga aos funcionários: R$ %.2f%n", mediaSalarial);

        scanner.close();
    }
}