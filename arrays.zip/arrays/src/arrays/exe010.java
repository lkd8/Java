package arrays;

import java.util.Arrays;
import java.util.Random;

public class exe010 {

    public static void main(String[] args) {
        Random random = new Random();
        int[] vetor = new int[10];

        // Preenche o vetor com valores aleatórios
        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = random.nextInt(100);  // Valores aleatórios entre 0 e 99
        }

        // Imprime o vetor antes da ordenação
        System.out.println("Vetor antes da ordenação:");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
        System.out.println();

        // Ordena o vetor em ordem crescente
        Arrays.sort(vetor);

        // Imprime o vetor após a ordenação
        System.out.println("Vetor após a ordenação:");
        for (int numero : vetor) {
            System.out.print(numero + " ");
        }
        System.out.println();
    }
}