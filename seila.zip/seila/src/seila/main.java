package seila;

public class main {
	public static void main(String[] args) {

		banco banco = new banco();
		banco.menu();

	}

}
