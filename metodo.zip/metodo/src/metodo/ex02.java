package metodo;

import java.util.Scanner;

public class ex02 {

	public class Exercicio02 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			double a, b, c;
			
			System.out.print("Lado a --> ");
			a = sc.nextDouble();
			System.out.print("Lado b --> ");
			b = sc.nextDouble();
			System.out.print("Lado c --> ");
			c = sc.nextDouble();
			
			if(validar(a, b, c)) {
				classificar(a, b, c);
			}
			else {
				System.out.println("Os valores não formam um triângulo");
			}		
		}
		
		public static boolean validar(double a, double b, double c) {
			return (a < b + c && b < a + c && c < a + b);
		}
		
		public static void classificar(double a, double b, double c) {
			if(a == b && b == c) {
				System.out.println("Triângulo equilátero");
			}
			else if(a == b || a == c || b == c) {
				System.out.println("Triângulo isósceles");			
			}
			else {
				System.out.println("Triângulo escaleno");
			}
		}
	}
}
