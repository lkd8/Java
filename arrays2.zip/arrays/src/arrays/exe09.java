package arrays;

import java.util.Scanner;

public class exe09 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);


        System.out.print("quantidade de funcionarios: ");
        int funcionarios = in.nextInt();
        in.nextLine();

        String[] nomes = new String[funcionarios];
        double[] salarios = new double[funcionarios];


        for (int i = 0; i < funcionarios; i++) {
            System.out.print("nome do funcionario " + (i + 1) + ": ");
            nomes[i] = in.nextLine();

            System.out.print("salario de " + nomes[i] + ": ");
            salarios[i] = in.nextDouble();
            in.nextLine();
        }


        double total = 0;
        for (double salario : salarios) {
            total += salario;
        }
        double media = total / funcionarios;


        System.out.printf("pagamento total: R$ %.2f%n", total);
        System.out.printf("media salarial: R$ %.2f%n", media);

        in.close();
    }
}