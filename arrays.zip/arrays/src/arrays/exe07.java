package arrays;

import java.util.Scanner;

public class exe07 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Lê a quantidade de elementos do array
        System.out.print("Digite a quantidade de elementos no array: ");
        int n = scanner.nextInt();

        // Cria o array e armazena os elementos fornecidos pelo usuário
        int[] array = new int[n];
        System.out.println("Digite os elementos do array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Utiliza um HashMap para armazenar a frequência de cada elemento
        Map<Integer, Integer> frequencias = new HashMap<>();
        for (int num : array) {
            frequencias.put(num, frequencias.getOrDefault(num, 0) + 1);
        }

        // Encontra o grau do array (frequência máxima de qualquer elemento)
        int grau = 0;
        for (int freq : frequencias.values()) {
            if (freq > grau) {
                grau = freq;
            }
        }

        // Imprime o grau do array
        System.out.println("O grau do array é: " + grau);

        scanner.close();
    }
}