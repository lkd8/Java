package arrays;

import java.util.HashMap;
import java.util.Scanner;

public class exe07 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);


        System.out.print("quantidade de elementos:");
        int x = in.nextInt();

        
        int[] vetor = new int[x];
        System.out.println("elementos:");
        for (int i = 0; i < x; i++) {
            vetor[i] = in.nextInt();
        }


        HashMap < Integer, Integer > frequencias = new HashMap<>();
        for (int num : vetor) {
            frequencias.put(num, frequencias.getOrDefault(num, 0) + 1);
        }


        int grau = 0;
        for (int freq : frequencias.values()) {
            if (freq > grau) {
                grau = freq;
            }
        }


        System.out.println("grau: " + grau);

        in.close();
    }
}